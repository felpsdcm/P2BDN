# P2BDN
P2 de BD Não Relacional
Esse projeto foi realizado para prova de Banco de Dados Não Relacional, utilizando MONGODB, Python e Google Colab.
